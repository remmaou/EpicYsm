# Port YSM-Epic-Fight-Compat -> Fabric 1.21.1 (target: Fox Model Loader = mod id `yes_steve_model` 1.3.6)

Sumber: YSM-EpicFight-Compat (MIT, sakuraimikoto33), NeoForge 1.21.1, menargetkan YSM resmi lewat YSM Mapping API.
Ukuran: 231 file Java di main (sekitar 44 ribu baris) + 29 mixin.

## Tahap 1 (zip ini)
- Proyek Fabric (Loom, Mojang mappings) + workflow GitHub Actions. Jar Epic Fight Fabric dan Fox Model Loader ada di `libs/`.
- Import NeoForge dialihkan ke shim Epic Fight Fabric (IPayloadContext, PacketDistributor, PayloadRegistrar, bus, ClientTick/RenderFrame)
  dan shim kecil lokal (`fabric/shim`: Dist, OnlyIn, ModList, FMLPaths).
- File yang menyentuh NeoForge turun dari 54 menjadi 23 (daftar: SISA_FILE_NEOFORGE.txt). 6 di antaranya hanya memakai
  `ModConfigSpec`/`ModConfig` yang disediakan Forge Config API Port, jadi boleh tetap.
- Entrypoint sementara `CompatModFabric`: hanya mencatat log. Mod ini BELUM berfungsi dan belum dikompilasi.

## Sisa pekerjaan
1. Event NeoForge -> callback Fabric (belum ada di shim): ServerStopped, ServerTick, PlayerEvent (login/logout/clone),
   EntityLeaveLevel, EntityJoinLevel, EntityMount, LivingShieldBlock, TagsUpdated, Command, RenderPlayer, Screen,
   ClientPlayerNetwork, RegisterClientReloadListeners, FMLLoadComplete/ClientSetup, DamageContainer, CommonHooks.
2. `CompatMod` (@Mod) -> entrypoint Fabric penuh, registrasi payload (24 handler network memakai IPayloadContext shim).
3. Lapisan YSM: 5 file memakai YSM Mapping API (khusus YSM resmi yang diobfuscate) + 7 alias di `ysmref`.
   Fox Model Loader memakai nama kelas terbaca (`com.elfmcys.yesstevemodel`), jadi lapisan ini diganti dengan rujukan langsung.
   Perlu dicek tiap simbol yang dipakai terhadap jar Fox Model Loader.
4. 29 mixin: sebagian menarget Epic Fight (nama kelas sama di port Fabric, tetapi perlu dicek tiap target), sebagian menarget YSM
   lewat alias/mapping (harus diarahkan ulang ke kelas Fox Model Loader), sebagian menarget Configured/TouhouLittleMaid (dibuang dulu).
5. Integrasi opsional (Configured, ParCool, SWEM, TLM, Oculus): dibuang dulu, ditambah belakangan.
6. Menghidupkan kembali `mixins.json` (sengaja belum ada supaya jar tahap 1 tidak bisa crash saat dimuat).


## Tahap 2 (zip ini)
- Shim sendiri `fabric/shim`: Dist, OnlyIn, ModList, FMLPaths, ServerLifecycleHooks, event bus (`bus/`) dan kelas event bergaya NeoForge (`event/`).
  (Catatan: pengalihan tahap 1 ke shim bus Epic Fight salah karena API-nya berbeda; sudah dikembalikan ke shim sendiri.)
- `FabricEventBridge`: callback Fabric -> event: login/logout, clone, respawn, ganti dimensi, start/stop tracking, server tick, server stopped,
  entity join/leave (server dan klien), tags updated, client tick, disconnect klien, perintah klien, reload listener klien.
- Entrypoint `CompatModFabric` (umum) dan `CompatModFabricClient`; config lewat Forge Config API Port; paket jaringan lewat `PayloadRegistrar` Epic Fight.
- Stub Mapping API (`net.okitsu.ysmmapping.api`): simbol YSM resmi belum dipetakan ke Fox Model Loader, jadi fitur yang memakainya
  (roaming variables, ground speed query, texture/audio YSM, sinkron animasi) akan mati dengan aman dan mencatat peringatan di log.
- Pilihan model pemain dibaca lewat `ModelInfoCapability` milik Fox Model Loader (`getModelId`, `getSelectTexture`, `isDisabled`).

## Belum (tahap 3)
- `mixins.json` belum diaktifkan. Mixin yang tidak bergantung pada YSM/Configured masih ada di `mixin/`; yang bergantung disimpan di `_pending/`.
  Mixin yang menarget kelas YSM resmi harus diarahkan ke kelas Fox Model Loader.
- Belum ada padanan Fabric untuk: EntityMountEvent, LivingShieldBlockEvent (perlu mixin), ScreenEvent klik, RenderPlayerEvent.Pre (CombatRenderInterceptor tidak aktif).
- Memetakan simbol YSM satu per satu di `YsmMappingApi` (lihat daftar di `YsmSymbols`).
- Belum pernah dikompilasi: dari hasil build pertama, jumlah dan jenis error baru bisa diketahui.

## Tahap 2.1 (perbaikan build)
- Penyebab build gagal: `Mod was built with a newer version of Loom (1.14.476), you are using Loom (1.11.8)`.
  Jar Fox Model Loader dibuild dengan Loom 1.14.476, Loom proyek ini 1.11.8 menolaknya.
- Perbaikan: Loom `1.14-SNAPSHOT` + Gradle wrapper `9.2.1` (Loom 1.14 mensyaratkan Gradle 9.2).
- `OfficialClientModelSelection` sekarang membaca pilihan model langsung dari `ModelInfoCapability` Fox Model Loader
  (tanpa Mapping API/mixin). `MappedClientModelSelection` dihapus karena tidak dipakai lagi.
- Semua import `yesman.epicfight.*` dan `com.elfmcys.*` di source sudah dicek ada di jar `libs/` (0 yang hilang).
- Belum bisa dikompilasi di lingkungan pembuat (host Maven/Mojang diblokir); hasil kompilasi pertama datang dari GitHub Actions.
