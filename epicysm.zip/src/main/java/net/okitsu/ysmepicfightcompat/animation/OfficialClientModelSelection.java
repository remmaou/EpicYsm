package net.okitsu.ysmepicfightcompat.animation;

import com.elfmcys.yesstevemodel.capability.ModelInfoCapability;
import net.minecraft.world.entity.player.Player;

/**
 * Pilihan model sisi klien. Di Fox Model Loader pilihan model disimpan di {@link ModelInfoCapability}
 * (komponen entitas yang disinkronkan ke klien), jadi tidak perlu lagi menangkap objek state lewat mixin
 * atau Mapping API seperti pada YSM resmi.
 */
public final class OfficialClientModelSelection {
    private OfficialClientModelSelection() {
    }

    /** Dipertahankan agar pemanggil lama tetap kompatibel; Fox membaca pilihan langsung dari capability. */
    public static void register(Player player, Object state) {
    }

    static String modelId(Player player) {
        if (player == null) return null;
        try {
            return ModelInfoCapability.get(player)
                    .filter(info -> !info.isDisabled())
                    .map(ModelInfoCapability::getModelId)
                    .filter(id -> id != null && !id.isBlank())
                    .orElse(null);
        } catch (RuntimeException | LinkageError unavailable) {
            return null;
        }
    }

    public static void remove(Player player) {
    }

    public static void clear() {
    }
}
